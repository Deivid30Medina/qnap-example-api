<?php
return [
    'urlQnap' => env('NAS_URL_QNAP'),
];
